`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/01/12 16:42:56
// Design Name: 
// Module Name: round_robin_arb_tb2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module round_robin_arb_tb2();

genvar  i;

localparam  CHANNUM     = 4;

reg         clk     = 0;
reg         rst_n   = 0;
wire        ready      ;
wire [CHANNUM-1:0]  REQ_i      ;
wire [CHANNUM-1:0]  empty      ;
wire [CHANNUM-1:0]  REQ        ;
wire                INI        ;
wire                END        ;
wire [CHANNUM-1:0]  GNT        ;

reg [7:0]   cnt_req         = 0;
reg [7:0]   cnt_gnt0        = 0;
reg [7:0]   cnt_gnt1        = 0;
reg [7:0]   cnt_gnt2        = 0;
reg [7:0]   cnt_gnt3        = 0;
wire[7:0]   dat_gnt         [CHANNUM-1:0];

wire                all_req    ;
reg                 all_req_d  ;

always#10  clk <= ~clk;

initial begin
    #453
    rst_n   <= 1;
end

always@(posedge clk) begin
    if(~ready) begin
        cnt_req         <= 0;
        cnt_gnt0        <= 0;
        cnt_gnt1        <= 0;
        cnt_gnt2        <= 0;
        cnt_gnt3        <= 0;
    end else begin
        cnt_req         <= cnt_req + 1'b1;
        if(GNT[0]) 
            cnt_gnt0    <= (cnt_gnt0 == 4) ? 0 : cnt_gnt0 + 1;
        if(GNT[1]) 
            cnt_gnt1    <= (cnt_gnt1 == 5) ? 0 : cnt_gnt1 + 1;
        if(GNT[2]) 
            cnt_gnt2    <= (cnt_gnt2 == 6) ? 0 : cnt_gnt2 + 1;
        if(GNT[3]) 
            cnt_gnt3    <= (cnt_gnt3 == 7) ? 0 : cnt_gnt3 + 1;
    end
end

assign REQ_i[0] = (cnt_req > 1 && cnt_req <= 6) ;   //5
assign REQ_i[1] = (cnt_req > 2 && cnt_req <= 8) ;   //6
assign REQ_i[2] = (cnt_req > 3 && cnt_req <= 10);   //7
assign REQ_i[3] = (cnt_req > 4 && cnt_req <= 12);   //8

generate
    for(i=0; i<CHANNUM; i=i+1) begin
        sync_blkfifo#(
            .READ_MODE          ("fwft"),             //string; "std" or "fwft";
            .FIFO_MEMORY_TYPE   ("distributed"),           //string; "auto", "block", or "distributed";
            .DATA_WIDTH_W       (8),
            .DATA_WIDTH_R       (8),
            .DATA_DEPTH_W       (16),
            .DATA_DEPTH_R       (16)
        )u_syncfifo_dist(
            .rst                (~rst_n),
            .ready              (ready),
            .full               (),
            .empty              (empty[i]),
            
            .wr_clk             (clk),
            .wr_req             (REQ_i[i]),
            .wr_data            (i),
            .wr_count           (),
            .rd_req             (GNT[i]),
            .rd_data            (dat_gnt[i]),
            .rd_vld             (),
            .rd_count           ()
        );
        assign REQ[i] = ~empty[i];
    end
endgenerate

assign all_req = |REQ;

always@(posedge clk)
    all_req_d   <= all_req;
    
assign INI = all_req && ~all_req_d;
assign END = GNT[3] ? (cnt_gnt3 == 7) : 
             GNT[2] ? (cnt_gnt2 == 6) : 
             GNT[1] ? (cnt_gnt1 == 5) : 
             GNT[0] ? (cnt_gnt0 == 4) : 'b0;

round_robin_arbiter#(
    .CHANNUM(CHANNUM)
)round_robin_arbiter_inst(
    .clk        (clk    )  ,
    .rst_n      (rst_n  )  ,
    
    .request    (REQ    )  ,
    .reqstart   (INI    )  ,
    .grantend   (END    )  ,
    .grant      (GNT    )
);

endmodule
