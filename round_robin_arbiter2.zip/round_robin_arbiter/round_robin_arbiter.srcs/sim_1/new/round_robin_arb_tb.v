`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/01/12 16:42:56
// Design Name: 
// Module Name: round_robin_arb_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module round_robin_arb_tb();

localparam  CHANNUM     = 5;

reg         clk     = 0;
reg         rst_n   = 0;
reg [CHANNUM-1:0]   REQ     = 0;
reg                 INI     = 0;
reg                 END     = 0;
wire [CHANNUM-1:0]  GNT        ;

reg [3:0]   state_cnt   = 0;
reg [3:0]   state       = 0;

always# 10  clk <= ~clk;

initial begin
    #453
    rst_n   <= 1;
end

always@(posedge clk) begin
    if(!rst_n) begin
        state       <= 0;
        state_cnt   <= 0;
        INI         <= 0;
        END         <= 0;
        REQ         <= {CHANNUM{1'b0}};
    end else begin
        case(state)
            0: begin
                state       <= 1;
                INI         <= 0;
                END         <= 0;
                REQ         <= {CHANNUM{1'b0}};
            end
            1: begin
                REQ     <= 5'b00001;    // GNT = 00001
                if(state_cnt == 9) begin
                    state_cnt   <= 0;
                    END         <= 1;
                    state       <= state + 1;
                end else begin
                    END         <= 0;
                    if(state_cnt == 0)
                        INI     <= 1;
                    else
                        INI     <= 0;
                    state_cnt   <= state_cnt + 1;
                end
            end
            2: begin
                REQ     <= 5'b01001;    // GNT = 01000
                if(state_cnt == 9) begin
                    state_cnt   <= 0;
                    END         <= 1;
                    state       <= state + 1;
                end else begin
                    END         <= 0;
                    if(state_cnt == 0)
                        INI     <= 1;
                    else
                        INI     <= 0;
                    state_cnt   <= state_cnt + 1;
                end
            end
            3: begin
                REQ     <= 5'b00101;    // GNT = 00001
                if(state_cnt == 9) begin
                    state_cnt   <= 0;
                    END         <= 1;
                    state       <= state + 1;
                end else begin
                    END         <= 0;
                    if(state_cnt == 0)
                        INI     <= 1;
                    else
                        INI     <= 0;
                    state_cnt   <= state_cnt + 1;
                end
            end
            4: begin
                REQ     <= 5'b10011;    // GNT = 00010
                if(state_cnt == 9) begin
                    state_cnt   <= 0;
                    END         <= 1;
                    state       <= state + 1;
                end else begin
                    END         <= 0;
                    if(state_cnt == 0)
                        INI     <= 1;
                    else
                        INI     <= 0;
                    state_cnt   <= state_cnt + 1;
                end
            end
            5: begin
                REQ     <= 5'b01100;    // GNT = 00100
                if(state_cnt == 9) begin
                    state_cnt   <= 0;
                    END         <= 1;
                    state       <= state + 1;
                end else begin
                    END         <= 0;
                    if(state_cnt == 0)
                        INI     <= 1;
                    else
                        INI     <= 0;
                    state_cnt   <= state_cnt + 1;
                end
            end
        default: begin
            state       <= state;
            INI         <= 0;
            END         <= 0;
            REQ         <= {CHANNUM{1'b0}};
        end
        endcase
    end
end

round_robin_arbiter#(
    .CHANNUM(CHANNUM)
)round_robin_arbiter_inst(
    .clk        (clk    )  ,
    .rst_n      (rst_n  )  ,
    
    .request    (REQ    )  ,
    .reqstart   (INI    )  ,
    .grantend   (END    )  ,
    .grant      (GNT    )
);

endmodule
